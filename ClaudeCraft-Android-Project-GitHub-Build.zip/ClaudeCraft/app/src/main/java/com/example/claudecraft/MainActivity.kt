package com.example.claudecraft

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1C21)
private val Purple = Color(0xFFB9A0FF)
private val MainText = Color(0xFFF4F1FA)
private val Muted = Color(0xFFA5A2B0)

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClaudeCraftApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClaudeCraftApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("settings", 0) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://openrouter.ai/api/v1/chat/completions") ?: "") }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "anthropic/claude-3.5-sonnet") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf(ChatMessage("assistant", "Hej! Jag är ClaudeCraft. Jag kan hjälpa dig skriva Minecraft-mods, Fabric/Forge-kod, GUI-menyer och felsöka projekt. Vad vill du bygga?") ) }
    val client = remember { OkHttpClient.Builder().callTimeout(120, TimeUnit.SECONDS).build() }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Purple, onBackground = MainText, onSurface = MainText)) {
        Scaffold(containerColor = Bg, topBar = {
            TopAppBar(
                title = { Column { Text("ClaudeCraft", fontWeight = FontWeight.SemiBold, fontSize = 20.sp); Text("AI för kod & Minecraft", color = Muted, fontSize = 12.sp) } },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Inställningar", tint = MainText) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        }, bottomBar = {
            Column(Modifier.fillMaxWidth().background(Bg).padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF8D8D), fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.Bottom) {
                    BasicTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f).padding(vertical = 10.dp), textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 15.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Purple), decorationBox = { inner -> if (draft.isEmpty()) Text("Fråga om kod eller Minecraft…", color = Muted, fontSize = 14.sp); inner() })
                    IconButton(enabled = !busy && draft.isNotBlank(), onClick = {
                        val prompt = draft.trim(); draft = ""; error = ""; messages.add(ChatMessage("user", prompt)); busy = true
                        scope.launch {
                            try {
                                val answer = withContext(Dispatchers.IO) { askAI(client, endpoint, apiKey, model, messages.toList()) }
                                messages.add(ChatMessage("assistant", answer))
                            } catch (e: Exception) { error = "Kunde inte få svar: ${e.message ?: "kontrollera inställningarna"}" }
                            finally { busy = false }
                        }
                    }) { Icon(Icons.Default.ArrowUpward, "Skicka", tint = if (!busy && draft.isNotBlank()) Purple else Muted) }
                }
                Text("Anslut din egen API-tjänst i inställningar. Kostnader och gränser beror på leverantören.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 8.dp, top = 5.dp, bottom = 3.dp))
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { if (messages.size == 1) { Text("Vad ska vi skapa?", color = MainText, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Din kodassistent för Minecraft-projekt.", color = Muted, modifier = Modifier.padding(top = 5.dp)); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Suggestion("Fabric mod") { draft = "Skapa en enkel Fabric-mod och förklara hur jag bygger den." }; Suggestion("GUI-meny") { draft = "Skapa en Minecraft GUI-meny med knappar och förklara koden." } } } }
                items(messages) { msg ->
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (msg.role == "user") Alignment.End else Alignment.Start) {
                        Text(if (msg.role == "user") "DU" else "CLAUDECRAFT", color = if (msg.role == "user") Purple else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
                        Surface(color = if (msg.role == "user") Color(0xFF292338) else Panel, shape = RoundedCornerShape(16.dp)) { Text(msg.text, color = MainText, fontSize = 14.sp, modifier = Modifier.padding(13.dp)) }
                    }
                }
                if (busy) item { Text("Tänker…", color = Purple, modifier = Modifier.padding(vertical = 8.dp)) }
            }
        }
    }
    if (showSettings) {
        AlertDialog(onDismissRequest = { showSettings = false }, containerColor = Panel,
            title = { Text("AI-inställningar", color = MainText) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("OpenAI-kompatibel chat completions-endpoint", color = Muted, fontSize = 12.sp)
                OutlinedTextField(value = endpoint, onValueChange = { endpoint = it }, label = { Text("API endpoint") }, singleLine = true)
                OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Modell-ID") }, singleLine = true)
                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API-nyckel") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                Text("Nyckeln sparas lokalt på enheten. Dela inte APK:n med en personlig nyckel inlagd.", color = Muted, fontSize = 11.sp)
            } },
            confirmButton = { TextButton(onClick = { prefs.edit().putString("endpoint", endpoint).putString("model", model).putString("key", apiKey).apply(); showSettings = false }) { Text("Spara", color = Purple) } },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Avbryt", color = Muted) } }
        )
    }
}

@Composable
fun Suggestion(text: String, onClick: () -> Unit) { AssistChip(onClick = onClick, label = { Text(text, color = MainText) }, colors = AssistChipDefaults.assistChipColors(containerColor = Panel)) }

private fun askAI(client: OkHttpClient, endpoint: String, key: String, model: String, messages: List<ChatMessage>): String {
    require(endpoint.startsWith("https://")) { "Endpoint måste börja med https://" }
    require(key.isNotBlank()) { "Lägg till API-nyckel i inställningar" }
    require(model.isNotBlank()) { "Ange ett modell-ID" }
    val arr = JSONArray()
    arr.put(JSONObject().put("role", "system").put("content", "You are a highly capable coding assistant specializing in Minecraft Java mods, Fabric, Forge, commands, GUI design, debugging, and explaining code clearly. Help with legitimate single-player mods and authorized server testing. Reply in the user's language. Give complete, practical code when asked."))
    messages.takeLast(24).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.text)) }
    val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.4).toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    val request = Request.Builder().url(endpoint).header("Authorization", "Bearer $key").header("Content-Type", "application/json").post(body).build()
    client.newCall(request).execute().use { response ->
        val text = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}: ${text.take(240)}")
        val root = JSONObject(text)
        return root.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}
