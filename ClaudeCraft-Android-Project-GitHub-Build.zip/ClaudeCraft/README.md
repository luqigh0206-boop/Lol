# ClaudeCraft — Android Studio project

A Claude-inspired Android chat UI with a Minecraft coding assistant system prompt. It connects to an OpenAI-compatible Chat Completions endpoint (the default endpoint is OpenRouter, but you can change it).

## Build an APK
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder (`ClaudeCraft`) in Android Studio.
3. Allow Gradle sync to finish.
4. Use **Build > Build APK(s)**.
5. Android Studio shows the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Connect an AI model
Open the app's settings and enter:
- Endpoint: an HTTPS OpenAI-compatible `/chat/completions` endpoint
- Model ID: the exact model ID supported by your provider
- API key: your own provider key

The app does not include a provider key and cannot create unlimited tokens. Usage limits, availability and costs are controlled by the AI provider. For production, use a small backend to protect API keys instead of embedding a key in a distributable APK.

## Notes
- This is Android Studio source, not a prebuilt APK. A build environment is required to compile it.
- This starter stores settings locally on the device and keeps the latest 24 chat messages in the request context; chat history is not persisted after app restart.
