# Build ClaudeCraft from your phone using GitHub Actions

1. Extract this ZIP on your phone using your file manager or an archive app.
2. Open github.com and create a new repository named `ClaudeCraft`.
3. On the repository page, choose **Add file → Upload files**.
4. Upload the *contents* of this `ClaudeCraft` folder, including the hidden `.github/workflows/build-apk.yml` file. If the mobile site does not let you upload folders or hidden files, use the GitHub web editor to create `.github/workflows/build-apk.yml` with the contents of that file.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab and choose **Build ClaudeCraft APK**. Tap **Run workflow** if it has not started automatically.
7. When the workflow finishes successfully, open its run, scroll to **Artifacts**, and download `ClaudeCraft-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.
8. Android may ask you to allow installing apps from your browser or file manager. Only install APKs you built and trust.

The APK build does not include a paid AI service or unlimited tokens. To chat with a model, configure a compatible API endpoint and your own API key. Do not commit API keys into this public or private repository.
